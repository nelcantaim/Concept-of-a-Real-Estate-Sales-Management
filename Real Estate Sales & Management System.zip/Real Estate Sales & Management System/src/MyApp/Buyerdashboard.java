/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package MyApp;
import MyLib.Subdivision;
import MyLib.Block;
import MyLib.Lot;
import MyLib.LotStatus;
import MyLib.Buyer;

/**
 *
 * @author leeyan
 */

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class Buyerdashboard extends JFrame {

    // Design
    private static final Color BG_DARK      = new Color(13, 17, 28);
    private static final Color BG_PANEL     = new Color(20, 26, 40);
    private static final Color BG_CARD      = new Color(26, 34, 52);
    private static final Color ACCENT_BLUE  = new Color(72, 149, 239);
    private static final Color ACCENT_GREEN = new Color(76, 175, 130);
    private static final Color ACCENT_AMBER = new Color(230, 168, 74);
    private static final Color ACCENT_RED   = new Color(220, 90, 90);
    private static final Color TEAL         = new Color(74, 184, 168);
    private static final Color TEXT_PRIMARY = new Color(220, 230, 245);
    private static final Color TEXT_MUTED   = new Color(100, 120, 160);
    private static final Color BORDER_COLOR = new Color(35, 45, 65);

    // Singleton + logged-in buyer
    private final Subdivision db = Subdivision.getInstance();
    private final Buyer currentBuyer;

    // UI
    private JTable            lotTable;
    private DefaultTableModel tableModel;
    private JTable            myTable;
    private DefaultTableModel myTableModel;
    private JLabel            statusBar;
    private JComboBox<String> blockFilter;
    private JComboBox<String> sizeFilterCombo;

    //  CONSTRUCTOR
    public Buyerdashboard(Buyer buyer) {
        this.currentBuyer = buyer;
        buildUI();
        refreshAvailable();
        refreshMyLots();
    }

    //  BUILD UI
    private void buildUI() {
        setTitle("RESMS — Buyer Portal");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1100, 720);
        setMinimumSize(new Dimension(1000, 600));
        setLocationRelativeTo(null);
        getContentPane().setBackground(BG_DARK);
        setLayout(new BorderLayout());

        add(buildHeader(),    BorderLayout.NORTH);
        add(buildSidebar(),   BorderLayout.WEST);
        add(buildCenter(),    BorderLayout.CENTER);
        add(buildStatusBar(), BorderLayout.SOUTH);
    }

    // Header
    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(BG_PANEL);
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_COLOR));
        header.setPreferredSize(new Dimension(0, 60));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 0));
        left.setOpaque(false);
        left.setBorder(BorderFactory.createEmptyBorder(18, 0, 0, 0));
        JLabel dot = new JLabel("◆");
        dot.setForeground(TEAL);
        dot.setFont(new Font("Monospaced", Font.PLAIN, 16));
        JLabel title = new JLabel(db.getName().toUpperCase());
        title.setFont(new Font("Monospaced", Font.BOLD, 16));
        title.setForeground(TEXT_PRIMARY);
        JLabel loc = new JLabel(db.getLocation());
        loc.setFont(new Font("Monospaced", Font.PLAIN, 11));
        loc.setForeground(TEXT_MUTED);
        JLabel userChip = new JLabel("  ●  " + currentBuyer.getName() + "  [BUYER]");
        userChip.setFont(new Font("Monospaced", Font.PLAIN, 11));
        userChip.setForeground(TEAL);
        left.add(dot); left.add(title); left.add(loc); left.add(userChip);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        right.setOpaque(false);
        right.setBorder(BorderFactory.createEmptyBorder(16, 0, 0, 20));
        right.add(statChip(db.countByStatus(LotStatus.AVAILABLE) + " Available", ACCENT_GREEN));

        // My lots count
        long myCount = db.getLotsByBuyer(currentBuyer).size();
        right.add(statChip(myCount + " My Lot(s)", TEAL));

        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setFont(new Font("Monospaced", Font.PLAIN, 11));
        logoutBtn.setForeground(TEXT_MUTED);
        logoutBtn.setBackground(BG_CARD);
        logoutBtn.setFocusPainted(false);
        logoutBtn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR),
            BorderFactory.createEmptyBorder(4, 10, 4, 10)
        ));
        logoutBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        logoutBtn.addActionListener(e -> {
            currentBuyer.logout();
            dispose();
            SwingUtilities.invokeLater(() -> new LoginForm().setVisible(true));
        });
        right.add(logoutBtn);

        header.add(left,  BorderLayout.WEST);
        header.add(right, BorderLayout.EAST);
        return header;
    }

    private JLabel statChip(String text, Color color) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("Monospaced", Font.PLAIN, 11));
        lbl.setForeground(color);
        lbl.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(color.darker(), 1),
            BorderFactory.createEmptyBorder(3, 8, 3, 8)
        ));
        return lbl;
    }

    // Sidebar
    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(BG_PANEL);
        sidebar.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 0, 1, BORDER_COLOR),
            BorderFactory.createEmptyBorder(20, 0, 20, 0)
        ));
        sidebar.setPreferredSize(new Dimension(200, 0));

        sidebar.add(sideLabel("BROWSE LOTS"));
        sidebar.add(Box.createVerticalStrut(8));

        sidebar.add(sideFilterLabel("Block"));
        blockFilter = new JComboBox<>(new String[]{"All","1","2","3","4","5"});
        styleCombo(blockFilter);
        sidebar.add(blockFilter);
        sidebar.add(Box.createVerticalStrut(8));

        sidebar.add(sideFilterLabel("Size (sqm)"));
        sizeFilterCombo = new JComboBox<>(new String[]{"All","60.0","80.0","100.0","120.0","150.0"});
        styleCombo(sizeFilterCombo);
        sidebar.add(sizeFilterCombo);
        sidebar.add(Box.createVerticalStrut(12));

        sidebar.add(sideButton("Apply Filters", ACCENT_AMBER, e -> refreshAvailable()));
        sidebar.add(Box.createVerticalStrut(6));
        sidebar.add(sideButton("Clear Filters", TEXT_MUTED, e -> {
            blockFilter.setSelectedIndex(0);
            sizeFilterCombo.setSelectedIndex(0);
            refreshAvailable();
        }));
        sidebar.add(Box.createVerticalStrut(24));

        sidebar.add(sideLabel("MY ACCOUNT"));
        sidebar.add(Box.createVerticalStrut(8));
        sidebar.add(sideButton("My Lots", TEAL, e -> showMyLotsDialog()));
        sidebar.add(Box.createVerticalStrut(6));
        sidebar.add(sideButton("My Profile", TEXT_PRIMARY, e -> showProfileDialog()));

        sidebar.add(Box.createVerticalGlue());
        return sidebar;
    }

    // Center available lots only
    private JPanel buildCenter() {
        JPanel center = new JPanel(new BorderLayout());
        center.setBackground(BG_DARK);
        center.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        JLabel tableTitle = new JLabel("AVAILABLE LOTS  —  Browse and inquire with our sales office");
        tableTitle.setFont(new Font("Monospaced", Font.BOLD, 12));
        tableTitle.setForeground(TEXT_MUTED);
        tableTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        center.add(tableTitle, BorderLayout.NORTH);

        String[] cols = {"Lot ID","Block","Lot #","Size (sqm)","Price (PHP)","Status"};
        tableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        lotTable = new JTable(tableModel) {
            public Component prepareRenderer(TableCellRenderer r, int row, int col) {
                Component c = super.prepareRenderer(r, row, col);
                String status = (String) getValueAt(row, 5);
                if (isRowSelected(row)) {
                    c.setBackground(new Color(40, 60, 100));
                } else if ("RESERVED".equals(status)) {
                    c.setBackground(new Color(35, 30, 15));
                } else {
                    c.setBackground(row % 2 == 0 ? BG_CARD : BG_PANEL);
                }
                c.setForeground(TEXT_PRIMARY);
                return c;
            }
        };

        styleTable(lotTable);

        lotTable.getColumnModel().getColumn(5).setCellRenderer(
            (table, value, sel, foc, row, col) -> {
                JLabel lbl = new JLabel(value.toString(), SwingConstants.CENTER);
                lbl.setFont(new Font("Monospaced", Font.BOLD, 11));
                lbl.setOpaque(true);
                lbl.setBackground(sel ? new Color(40,60,100) : (row%2==0 ? BG_CARD : BG_PANEL));
                lbl.setForeground("AVAILABLE".equals(value.toString()) ? ACCENT_GREEN : ACCENT_AMBER);
                return lbl;
            }
        );

        JScrollPane scroll = new JScrollPane(lotTable);
        scroll.getViewport().setBackground(BG_DARK);
        scroll.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));
        center.add(scroll, BorderLayout.CENTER);

        // Info note at bottom
        JLabel note = new JLabel("  To reserve or purchase a lot, please contact our sales office or agent.");
        note.setFont(new Font("Monospaced", Font.PLAIN, 10));
        note.setForeground(TEXT_MUTED);
        note.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));
        center.add(note, BorderLayout.SOUTH);

        return center;
    }

    // Status bar
    private JPanel buildStatusBar() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(BG_PANEL);
        bar.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 0, 0, BORDER_COLOR),
            BorderFactory.createEmptyBorder(6, 16, 6, 16)
        ));
        statusBar = new JLabel("Ready.");
        statusBar.setFont(new Font("Monospaced", Font.PLAIN, 11));
        statusBar.setForeground(TEXT_MUTED);
        bar.add(statusBar, BorderLayout.WEST);
        JLabel info = new JLabel(db.getName() + " · " + db.getLocation());
        info.setFont(new Font("Monospaced", Font.PLAIN, 11));
        info.setForeground(TEXT_MUTED);
        bar.add(info, BorderLayout.EAST);
        return bar;
    }

    // Refresh available lots
    private void refreshAvailable() {
        tableModel.setRowCount(0);
        String selBlock = (String) blockFilter.getSelectedItem();
        String selSize  = (String) sizeFilterCombo.getSelectedItem();

        for (Block block : db.getBlocks()) {
            if (!"All".equals(selBlock) &&
                block.getBlockNumber() != Integer.parseInt(selBlock)) continue;
            for (Lot lot : block.getLots()) {
                // Buyers only see AVAILABLE and RESERVED (not SOLD)
                if (lot.getStatus() == LotStatus.SOLD) continue;
                if (!"All".equals(selSize) &&
                    lot.getSize() != Double.parseDouble(selSize)) continue;
                tableModel.addRow(new Object[]{
                    lot.getLotId(), lot.getBlockNumber(), lot.getLotNumber(),
                    lot.getSize(), String.format("₱%,.2f", lot.getPrice()),
                    lot.getStatus().toString()
                });
            }
        }
        setStatus("Showing " + tableModel.getRowCount() + " available/reserved lot(s).");
    }

    // Refresh my lots
    private void refreshMyLots() {
        if (myTableModel == null) return;
        myTableModel.setRowCount(0);
        for (Lot lot : db.getLotsByBuyer(currentBuyer)) {
            myTableModel.addRow(new Object[]{
                lot.getLotId(), lot.getBlockNumber(), lot.getLotNumber(),
                lot.getSize(), String.format("₱%,.2f", lot.getPrice()),
                lot.getStatus().toString()
            });
        }
    }

    // My Lots Dialog
    private void showMyLotsDialog() {
        JDialog dlg = new JDialog(this, "My Lots — " + currentBuyer.getName(), true);
        dlg.setSize(800, 400);
        dlg.setLocationRelativeTo(this);
        dlg.getContentPane().setBackground(BG_PANEL);
        ((JPanel) dlg.getContentPane()).setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
        dlg.setLayout(new BorderLayout(0, 10));

        JLabel title = new JLabel("Lots reserved or purchased by you");
        title.setFont(new Font("Monospaced", Font.BOLD, 12));
        title.setForeground(TEAL);
        dlg.add(title, BorderLayout.NORTH);

        String[] cols = {"Lot ID","Block","Lot #","Size (sqm)","Price (PHP)","Status"};
        myTableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        refreshMyLots();

        myTable = new JTable(myTableModel);
        styleTable(myTable);

        myTable.getColumnModel().getColumn(5).setCellRenderer(
            (table, value, sel, foc, row, col) -> {
                JLabel lbl = new JLabel(value.toString(), SwingConstants.CENTER);
                lbl.setFont(new Font("Monospaced", Font.BOLD, 11));
                lbl.setOpaque(true);
                lbl.setBackground(sel ? new Color(40,60,100) : (row%2==0 ? BG_CARD : BG_PANEL));
                lbl.setForeground("SOLD".equals(value.toString()) ? ACCENT_RED : ACCENT_AMBER);
                return lbl;
            }
        );

        JScrollPane sp = new JScrollPane(myTable);
        sp.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));
        dlg.add(sp, BorderLayout.CENTER);

        if (myTableModel.getRowCount() == 0) {
            JLabel empty = new JLabel("You have no lots yet.", SwingConstants.CENTER);
            empty.setFont(new Font("Monospaced", Font.PLAIN, 12));
            empty.setForeground(TEXT_MUTED);
            dlg.add(empty, BorderLayout.SOUTH);
        }

        dlg.setVisible(true);
    }

    // Profile Dialog
    private void showProfileDialog() {
        JDialog dlg = new JDialog(this, "My Profile", true);
        dlg.setSize(360, 260);
        dlg.setLocationRelativeTo(this);
        dlg.getContentPane().setBackground(BG_PANEL);
        dlg.setLayout(null);

        String[] labels = {"Buyer ID", "Name", "Contact", "Email", "Username"};
        String[] values = {
            currentBuyer.getBuyerId(),
            currentBuyer.getName(),
            currentBuyer.getContact(),
            currentBuyer.getEmail(),
            currentBuyer.getUsername()
        };

        int y = 20;
        for (int i = 0; i < labels.length; i++) {
            JLabel lbl = new JLabel(labels[i]);
            lbl.setFont(new Font("Monospaced", Font.PLAIN, 10));
            lbl.setForeground(TEXT_MUTED);
            lbl.setBounds(20, y, 140, 16);
            dlg.add(lbl);

            JLabel val = new JLabel(values[i]);
            val.setFont(new Font("Monospaced", Font.BOLD, 11));
            val.setForeground(TEXT_PRIMARY);
            val.setBounds(160, y, 180, 16);
            dlg.add(val);

            y += 36;
        }

        dlg.setVisible(true);
    }

    //  HELPERS
    private void styleTable(JTable table) {
        table.setFont(new Font("Monospaced", Font.PLAIN, 12));
        table.setRowHeight(28);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 1));
        table.setBackground(BG_CARD);
        table.setForeground(TEXT_PRIMARY);
        table.setFillsViewportHeight(true);
        JTableHeader th = table.getTableHeader();
        th.setFont(new Font("Monospaced", Font.BOLD, 11));
        th.setBackground(BG_PANEL);
        th.setForeground(TEXT_MUTED);
        th.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_COLOR));
    }

    private JLabel sideLabel(String text) {
        JLabel lbl = new JLabel("  " + text);
        lbl.setFont(new Font("Monospaced", Font.BOLD, 10));
        lbl.setForeground(TEXT_MUTED);
        lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        lbl.setMaximumSize(new Dimension(200, 20));
        return lbl;
    }

    private JLabel sideFilterLabel(String text) {
        JLabel lbl = new JLabel("  " + text);
        lbl.setFont(new Font("Monospaced", Font.PLAIN, 10));
        lbl.setForeground(TEXT_MUTED);
        lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        lbl.setMaximumSize(new Dimension(200, 18));
        return lbl;
    }

    private JButton sideButton(String text, Color color, ActionListener action) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Monospaced", Font.PLAIN, 12));
        btn.setForeground(color);
        btn.setBackground(BG_CARD);
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 3, 0, 0, color),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        btn.setAlignmentX(Component.LEFT_ALIGNMENT);
        btn.setMaximumSize(new Dimension(200, 40));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setFocusPainted(false);
        btn.addActionListener(action);
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btn.setBackground(BORDER_COLOR); }
            public void mouseExited(MouseEvent e)  { btn.setBackground(BG_CARD); }
        });
        return btn;
    }

    private void styleCombo(JComboBox<String> combo) {
        combo.setFont(new Font("Monospaced", Font.PLAIN, 11));
        combo.setBackground(BG_CARD);
        combo.setForeground(TEXT_PRIMARY);
        combo.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));
        combo.setMaximumSize(new Dimension(180, 30));
        combo.setAlignmentX(Component.LEFT_ALIGNMENT);
    }

    private void setStatus(String msg) { statusBar.setText(msg); }
}

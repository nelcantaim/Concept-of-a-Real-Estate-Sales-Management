/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MyApp;
import MyLib.Buyer;
import MyLib.Subdivision;
import MyLib.Admin;

/**
 *
 * @author leeyan
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LoginForm extends JFrame {

    // design
    private static final Color BG_DARK    = new Color(13, 17, 28);
    private static final Color BG_PANEL   = new Color(20, 26, 40);
    private static final Color BG_CARD    = new Color(26, 34, 52);
    private static final Color ACCENT     = new Color(72, 149, 239);
    private static final Color TEAL       = new Color(74, 184, 168);
    private static final Color AMBER      = new Color(230, 168, 74);
    private static final Color TEXT       = new Color(220, 230, 245);
    private static final Color TEXT_MUTED = new Color(100, 120, 160);
    private static final Color BORDER     = new Color(35, 45, 65);
    private static final Color ERROR      = new Color(220, 90, 90);
    private static final Color SUCCESS    = new Color(76, 175, 130);

    // Singleton
    private final Subdivision db = Subdivision.getInstance();
    private static int buyerCounter = 6; // continues from initBuyers

    // Mode toggle
    private boolean isAdminMode = false;

    // Dynamic UI refs
    private JLabel  roleLabel;
    private JButton toggleBtn;
    private JButton registerBtn;
    private JLabel  msgLabel;
    private JTextField usernameField;
    private JPasswordField passwordField;

    // MAIN
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
            } catch (Exception ignored) {}
            new LoginForm();
        });
    }

    //  CONSTRUCTOR
    public LoginForm() {
        buildUI();
    }

    //  UI
    private void buildUI() {
        setTitle("RESMS — Login");
        setSize(440, 520);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        getContentPane().setBackground(BG_DARK);
        setLayout(null);

        // Title
        JLabel logo = new JLabel("Sundowners", SwingConstants.CENTER);
        logo.setFont(new Font("Monospaced", Font.BOLD, 36));
        logo.setForeground(ACCENT);
        logo.setBounds(0, 36, 440, 50);
        add(logo);

        JLabel subtitle = new JLabel("Real Estate Sales & Management System", SwingConstants.CENTER);
        subtitle.setFont(new Font("Monospaced", Font.PLAIN, 10));
        subtitle.setForeground(TEXT_MUTED);
        subtitle.setBounds(0, 86, 440, 20);
        add(subtitle);

        // Role toggle tabs
        JPanel tabs = new JPanel(null);
        tabs.setBackground(BG_PANEL);
        tabs.setBorder(BorderFactory.createLineBorder(BORDER));
        tabs.setBounds(60, 118, 320, 36);
        add(tabs);

        JButton buyerTab = new JButton("Buyer");
        buyerTab.setFont(new Font("Monospaced", Font.BOLD, 11));
        buyerTab.setForeground(TEXT);
        buyerTab.setBackground(ACCENT);
        buyerTab.setFocusPainted(false);
        buyerTab.setBorderPainted(false);
        buyerTab.setBounds(0, 0, 160, 36);
        tabs.add(buyerTab);

        JButton adminTab = new JButton("Admin / Agent");
        adminTab.setFont(new Font("Monospaced", Font.BOLD, 11));
        adminTab.setForeground(TEXT_MUTED);
        adminTab.setBackground(BG_PANEL);
        adminTab.setFocusPainted(false);
        adminTab.setBorderPainted(false);
        adminTab.setBounds(160, 0, 160, 36);
        tabs.add(adminTab);

        // Card
        JPanel card = new JPanel(null);
        card.setBackground(BG_PANEL);
        card.setBorder(BorderFactory.createLineBorder(BORDER));
        card.setBounds(60, 164, 320, 240);
        add(card);

        roleLabel = new JLabel("BUYER LOGIN");
        roleLabel.setFont(new Font("Monospaced", Font.BOLD, 11));
        roleLabel.setForeground(TEAL);
        roleLabel.setBounds(20, 16, 280, 20);
        card.add(roleLabel);

        // Username
        JLabel uLabel = new JLabel("Username");
        uLabel.setFont(new Font("Monospaced", Font.PLAIN, 10));
        uLabel.setForeground(TEXT_MUTED);
        uLabel.setBounds(20, 46, 280, 16);
        card.add(uLabel);

        usernameField = new JTextField();
        styleField(usernameField);
        usernameField.setBounds(20, 64, 280, 34);
        card.add(usernameField);

        // Password
        JLabel pLabel = new JLabel("Password");
        pLabel.setFont(new Font("Monospaced", Font.PLAIN, 10));
        pLabel.setForeground(TEXT_MUTED);
        pLabel.setBounds(20, 108, 280, 16);
        card.add(pLabel);

        passwordField = new JPasswordField();
        styleField(passwordField);
        passwordField.setBounds(20, 126, 280, 34);
        card.add(passwordField);

        // Message label
        msgLabel = new JLabel("", SwingConstants.CENTER);
        msgLabel.setFont(new Font("Monospaced", Font.PLAIN, 10));
        msgLabel.setForeground(ERROR);
        msgLabel.setBounds(0, 170, 320, 18);
        card.add(msgLabel);

        // Login button
        JButton loginBtn = styledButton("LOGIN", ACCENT);
        loginBtn.setBounds(20, 196, 280, 34);
        card.add(loginBtn);

        // Register section (buyer only)
        JLabel registerHint = new JLabel("Don't have an account?", SwingConstants.CENTER);
        registerHint.setFont(new Font("Monospaced", Font.PLAIN, 10));
        registerHint.setForeground(TEXT_MUTED);
        registerHint.setBounds(0, 424, 440, 18);
        add(registerHint);

        registerBtn = new JButton("REGISTER AS BUYER");
        registerBtn.setFont(new Font("Monospaced", Font.PLAIN, 11));
        registerBtn.setForeground(TEAL);
        registerBtn.setBackground(BG_DARK);
        registerBtn.setFocusPainted(false);
        registerBtn.setBorderPainted(false);
        registerBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        registerBtn.setBounds(120, 444, 200, 28);
        add(registerBtn);

        // Tab toggle actions
        buyerTab.addActionListener(e -> {
            isAdminMode = false;
            roleLabel.setText("BUYER LOGIN");
            roleLabel.setForeground(TEAL);
            buyerTab.setBackground(ACCENT);
            buyerTab.setForeground(TEXT);
            adminTab.setBackground(BG_PANEL);
            adminTab.setForeground(TEXT_MUTED);
            registerBtn.setVisible(true);
            registerHint.setVisible(true);
            msgLabel.setText("");
            usernameField.setText("");
            passwordField.setText("");
        });

        adminTab.addActionListener(e -> {
            isAdminMode = true;
            roleLabel.setText("ADMIN / AGENT LOGIN");
            roleLabel.setForeground(AMBER);
            adminTab.setBackground(AMBER);
            adminTab.setForeground(new Color(13, 17, 28));
            buyerTab.setBackground(BG_PANEL);
            buyerTab.setForeground(TEXT_MUTED);
            registerBtn.setVisible(false);
            registerHint.setVisible(false);
            msgLabel.setText("");
            usernameField.setText("");
            passwordField.setText("");
        });

        // Login action
        ActionListener loginAction = e -> {
            String inputUser = usernameField.getText().trim();
            String inputPass = new String(passwordField.getPassword()).trim();

            if (inputUser.isEmpty() || inputPass.isEmpty()) {
                msgLabel.setForeground(ERROR);
                msgLabel.setText("Please fill in all fields.");
                return;
            }

            if (isAdminMode) {
                // Admin login
                Admin admin = db.authenticateAdmin(inputUser, inputPass);
                if (admin != null) {
                    dispose();
                    SwingUtilities.invokeLater(() -> new Admindashboard(admin).setVisible(true));
                } else {
                    msgLabel.setForeground(ERROR);
                    msgLabel.setText("Invalid admin credentials.");
                    passwordField.setText("");
                }
            } else {
                // Buyer login
                Buyer buyer = db.authenticateBuyer(inputUser, inputPass);
                if (buyer != null) {
                    dispose();
                    SwingUtilities.invokeLater(() -> new Buyerdashboard(buyer).setVisible(true));
                } else {
                    msgLabel.setForeground(ERROR);
                    msgLabel.setText("Invalid username or password.");
                    passwordField.setText("");
                }
            }
        };

        loginBtn.addActionListener(loginAction);
        passwordField.addActionListener(loginAction);
        registerBtn.addActionListener(e -> showRegisterDialog());

        setVisible(true);
    }

    //  REGISTER DIALOG
    private void showRegisterDialog() {
        JDialog dlg = new JDialog(this, "Register as Buyer", true);
        dlg.setSize(440, 480);
        dlg.setLocationRelativeTo(this);
        dlg.setResizable(false);
        dlg.getContentPane().setBackground(BG_DARK);
        dlg.setLayout(null);

        JLabel title = new JLabel("CREATE ACCOUNT", SwingConstants.CENTER);
        title.setFont(new Font("Monospaced", Font.BOLD, 14));
        title.setForeground(TEAL);
        title.setBounds(0, 20, 440, 24);
        dlg.add(title);

        JLabel sub = new JLabel("Fill in your buyer information", SwingConstants.CENTER);
        sub.setFont(new Font("Monospaced", Font.PLAIN, 10));
        sub.setForeground(TEXT_MUTED);
        sub.setBounds(0, 46, 440, 16);
        dlg.add(sub);

        JPanel form = new JPanel(null);
        form.setBackground(BG_PANEL);
        form.setBorder(BorderFactory.createLineBorder(BORDER));
        form.setBounds(30, 72, 380, 310);
        dlg.add(form);

        JTextField fName    = addFormField(form, "Full Name",  20,  16);
        JTextField fContact = addFormField(form, "Contact",    20,  82);
        JTextField fEmail   = addFormField(form, "Email",      20, 148);
        JTextField fUser    = addFormField(form, "Username",  210,  16);

        JPasswordField fPass = new JPasswordField();
        styleField(fPass);
        addLabel(form, "Password", 210, 82);
        fPass.setBounds(210, 100, 150, 32);
        form.add(fPass);

        JPasswordField fConfirm = new JPasswordField();
        styleField(fConfirm);
        addLabel(form, "Confirm Password", 210, 148);
        fConfirm.setBounds(210, 166, 150, 32);
        form.add(fConfirm);

        JLabel errLabel = new JLabel("", SwingConstants.CENTER);
        errLabel.setFont(new Font("Monospaced", Font.PLAIN, 10));
        errLabel.setForeground(ERROR);
        errLabel.setBounds(0, 268, 380, 18);
        form.add(errLabel);

        JButton confirmBtn = styledButton("CREATE ACCOUNT", TEAL);
        confirmBtn.setBounds(30, 400, 380, 36);
        dlg.add(confirmBtn);

        confirmBtn.addActionListener(e -> {
            String name    = fName.getText().trim();
            String contact = fContact.getText().trim();
            String email   = fEmail.getText().trim();
            String user    = fUser.getText().trim();
            String pass    = new String(fPass.getPassword()).trim();
            String confirm = new String(fConfirm.getPassword()).trim();

            if (name.isEmpty() || contact.isEmpty() || email.isEmpty() ||
                user.isEmpty() || pass.isEmpty() || confirm.isEmpty()) {
                errLabel.setText("All fields are required.");
                return;
            }
            if (!pass.equals(confirm)) {
                errLabel.setText("Passwords do not match.");
                return;
            }
            if (pass.length() < 6) {
                errLabel.setText("Password must be at least 6 characters.");
                return;
            }
            if (db.getBuyers().stream().anyMatch(b -> b.getUsername().equals(user))) {
                errLabel.setText("Username already taken.");
                return;
            }

            String buyerId = String.format("B%03d", buyerCounter++);
            db.getBuyers().add(new Buyer(buyerId, name, contact, email, user, pass));
            dlg.dispose();
            msgLabel.setForeground(SUCCESS);
            msgLabel.setText("Account created! You can now log in.");
        });

        dlg.setVisible(true);
    }

    //  HELPERS
    private JTextField addFormField(JPanel panel, String label, int x, int y) {
        addLabel(panel, label, x, y);
        JTextField tf = new JTextField();
        styleField(tf);
        tf.setBounds(x, y + 18, 150, 32);
        panel.add(tf);
        return tf;
    }

    private void addLabel(JPanel panel, String text, int x, int y) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("Monospaced", Font.PLAIN, 10));
        lbl.setForeground(TEXT_MUTED);
        lbl.setBounds(x, y, 160, 16);
        panel.add(lbl);
    }

    private void styleField(JTextField tf) {
        tf.setFont(new Font("Monospaced", Font.PLAIN, 12));
        tf.setBackground(BG_CARD);
        tf.setForeground(TEXT);
        tf.setCaretColor(TEXT);
        tf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER),
            BorderFactory.createEmptyBorder(4, 8, 4, 8)
        ));
    }

    private JButton styledButton(String text, Color color) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Monospaced", Font.BOLD, 13));
        btn.setForeground(Color.WHITE);
        btn.setBackground(color);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 0, 8, 0));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MyApp;
import MyLib.Subdivision;
import MyLib.Block;
import MyLib.Lot;
import MyLib.LotStatus;
import MyLib.Transaction;
import MyLib.Admin;
import MyLib.Buyer;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class Admindashboard extends JFrame {

    //  Design
    private static final Color BG_DARK      = new Color(13, 17, 28);
    private static final Color BG_PANEL     = new Color(20, 26, 40);
    private static final Color BG_CARD      = new Color(26, 34, 52);
    private static final Color ACCENT_BLUE  = new Color(72, 149, 239);
    private static final Color ACCENT_GREEN = new Color(76, 175, 130);
    private static final Color ACCENT_AMBER = new Color(230, 168, 74);
    private static final Color ACCENT_RED   = new Color(220, 90, 90);
    private static final Color TEXT_PRIMARY = new Color(220, 230, 245);
    private static final Color TEXT_MUTED   = new Color(100, 120, 160);
    private static final Color BORDER_COLOR = new Color(35, 45, 65);

    //  Singleton + logged-in admin
    private final Subdivision db = Subdivision.getInstance();
    private final Admin currentAdmin;

    // UI
    private JTable            lotTable;
    private DefaultTableModel tableModel;
    private JLabel            statusBar;
    private JComboBox<String> blockFilter;
    private JComboBox<String> statusFilter;
    private JTextField        sizeFilter;

    //  CONSTRUCTOR
    public Admindashboard(Admin admin) {
        this.currentAdmin = admin;
        buildUI();
        refreshTable();
    }

    //  BUILD UI
    private void buildUI() {
        setTitle("RESMS — Admin Dashboard");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1100, 720);
        setMinimumSize(new Dimension(1000, 600));
        setLocationRelativeTo(null);
        getContentPane().setBackground(BG_DARK);
        setLayout(new BorderLayout());

        add(buildHeader(),    BorderLayout.NORTH);
        add(buildSidebar(),   BorderLayout.WEST);
        add(buildCenter(),    BorderLayout.CENTER);
        add(buildStatusBar(), BorderLayout.SOUTH);
    }

    // Header
    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(BG_PANEL);
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_COLOR));
        header.setPreferredSize(new Dimension(0, 60));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 0));
        left.setOpaque(false);
        left.setBorder(BorderFactory.createEmptyBorder(18, 0, 0, 0));
        JLabel dot = new JLabel("◆");
        dot.setForeground(ACCENT_AMBER);
        dot.setFont(new Font("Monospaced", Font.PLAIN, 16));
        JLabel title = new JLabel(db.getName().toUpperCase());
        title.setFont(new Font("Monospaced", Font.BOLD, 16));
        title.setForeground(TEXT_PRIMARY);
        JLabel loc = new JLabel(db.getLocation());
        loc.setFont(new Font("Monospaced", Font.PLAIN, 11));
        loc.setForeground(TEXT_MUTED);
        // Admin chip
        JLabel adminChip = new JLabel("  ▲  " + currentAdmin.getName() + "  [ADMIN]");
        adminChip.setFont(new Font("Monospaced", Font.PLAIN, 11));
        adminChip.setForeground(ACCENT_AMBER);
        left.add(dot); left.add(title); left.add(loc); left.add(adminChip);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        right.setOpaque(false);
        right.setBorder(BorderFactory.createEmptyBorder(16, 0, 0, 20));
        right.add(statChip(db.getTotalBlocks() + " Blocks",                         TEXT_MUTED));
        right.add(statChip(db.countByStatus(LotStatus.AVAILABLE) + " Available",    ACCENT_GREEN));
        right.add(statChip(db.countByStatus(LotStatus.RESERVED)  + " Reserved",     ACCENT_AMBER));
        right.add(statChip(db.countByStatus(LotStatus.SOLD)      + " Sold",         ACCENT_RED));
        right.add(statChip(db.getBuyers().size() + " Buyers",                       ACCENT_BLUE));

        JButton logoutBtn = logoutButton();
        right.add(logoutBtn);

        header.add(left,  BorderLayout.WEST);
        header.add(right, BorderLayout.EAST);
        return header;
    }

    private JLabel statChip(String text, Color color) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("Monospaced", Font.PLAIN, 11));
        lbl.setForeground(color);
        lbl.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(color.darker(), 1),
            BorderFactory.createEmptyBorder(3, 8, 3, 8)
        ));
        return lbl;
    }

    private JButton logoutButton() {
        JButton btn = new JButton("Logout");
        btn.setFont(new Font("Monospaced", Font.PLAIN, 11));
        btn.setForeground(TEXT_MUTED);
        btn.setBackground(BG_CARD);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR),
            BorderFactory.createEmptyBorder(4, 10, 4, 10)
        ));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addActionListener(e -> {
            currentAdmin.logout();
            dispose();
            SwingUtilities.invokeLater(() -> new LoginForm().setVisible(true));
        });
        return btn;
    }

    // Sidebar
    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(BG_PANEL);
        sidebar.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 0, 1, BORDER_COLOR),
            BorderFactory.createEmptyBorder(20, 0, 20, 0)
        ));
        sidebar.setPreferredSize(new Dimension(200, 0));

        sidebar.add(sideLabel("ACTIONS"));
        sidebar.add(Box.createVerticalStrut(8));
        sidebar.add(sideButton("Reserve Lot",   ACCENT_BLUE,  e -> showReserveDialog()));
        sidebar.add(Box.createVerticalStrut(6));
        sidebar.add(sideButton("Buy Lot",        ACCENT_GREEN, e -> showBuyDialog()));
        sidebar.add(Box.createVerticalStrut(6));
        sidebar.add(sideButton("View Buyers",    ACCENT_AMBER, e -> showBuyerListDialog()));
        sidebar.add(Box.createVerticalStrut(24));

        sidebar.add(sideLabel("FILTERS"));
        sidebar.add(Box.createVerticalStrut(8));

        sidebar.add(sideFilterLabel("Block"));
        blockFilter = new JComboBox<>(new String[]{"All","1","2","3","4","5"});
        styleCombo(blockFilter);
        sidebar.add(blockFilter);
        sidebar.add(Box.createVerticalStrut(8));

        sidebar.add(sideFilterLabel("Status"));
        statusFilter = new JComboBox<>(new String[]{"All","AVAILABLE","RESERVED","SOLD"});
        styleCombo(statusFilter);
        sidebar.add(statusFilter);
        sidebar.add(Box.createVerticalStrut(8));

        sidebar.add(sideFilterLabel("Size (sqm)"));
        sizeFilter = new JTextField();
        styleTextField(sizeFilter);
        sidebar.add(sizeFilter);
        sidebar.add(Box.createVerticalStrut(12));

        sidebar.add(sideButton("Apply Filters", ACCENT_AMBER, e -> refreshTable()));
        sidebar.add(Box.createVerticalStrut(6));
        sidebar.add(sideButton("Clear Filters", TEXT_MUTED, e -> {
            blockFilter.setSelectedIndex(0);
            statusFilter.setSelectedIndex(0);
            sizeFilter.setText("");
            refreshTable();
        }));
        sidebar.add(Box.createVerticalStrut(24));

        sidebar.add(sideLabel("REPORTS"));
        sidebar.add(Box.createVerticalStrut(8));
        sidebar.add(sideButton("Full Report", TEXT_PRIMARY, e -> showReport()));

        sidebar.add(Box.createVerticalGlue());
        return sidebar;
    }

    // Center table
    private JPanel buildCenter() {
        JPanel center = new JPanel(new BorderLayout());
        center.setBackground(BG_DARK);
        center.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        JLabel tableTitle = new JLabel("LOT INVENTORY  —  ALL LOTS");
        tableTitle.setFont(new Font("Monospaced", Font.BOLD, 13));
        tableTitle.setForeground(TEXT_MUTED);
        tableTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        center.add(tableTitle, BorderLayout.NORTH);

        String[] cols = {"Lot ID","Block","Lot #","Size (sqm)","Price (PHP)","Status","Buyer"};
        tableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        lotTable = new JTable(tableModel) {
            public Component prepareRenderer(TableCellRenderer r, int row, int col) {
                Component c = super.prepareRenderer(r, row, col);
                String status = (String) getValueAt(row, 5);
                if (isRowSelected(row)) {
                    c.setBackground(new Color(40, 60, 100));
                } else if ("SOLD".equals(status)) {
                    c.setBackground(new Color(35, 20, 20));
                } else if ("RESERVED".equals(status)) {
                    c.setBackground(new Color(35, 30, 15));
                } else {
                    c.setBackground(row % 2 == 0 ? BG_CARD : BG_PANEL);
                }
                c.setForeground(TEXT_PRIMARY);
                return c;
            }
        };

        styleTable(lotTable);

        lotTable.getColumnModel().getColumn(5).setCellRenderer(
            (table, value, sel, foc, row, col) -> {
                JLabel lbl = new JLabel(value.toString(), SwingConstants.CENTER);
                lbl.setFont(new Font("Monospaced", Font.BOLD, 11));
                lbl.setOpaque(true);
                lbl.setBackground(sel ? new Color(40,60,100) : (row%2==0 ? BG_CARD : BG_PANEL));
                String v = value.toString();
                lbl.setForeground("AVAILABLE".equals(v) ? ACCENT_GREEN : "RESERVED".equals(v) ? ACCENT_AMBER : ACCENT_RED);
                return lbl;
            }
        );

        JScrollPane scroll = new JScrollPane(lotTable);
        scroll.getViewport().setBackground(BG_DARK);
        scroll.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));
        center.add(scroll, BorderLayout.CENTER);
        return center;
    }

    // Status bar
    private JPanel buildStatusBar() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(BG_PANEL);
        bar.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 0, 0, BORDER_COLOR),
            BorderFactory.createEmptyBorder(6, 16, 6, 16)
        ));
        statusBar = new JLabel("Ready.");
        statusBar.setFont(new Font("Monospaced", Font.PLAIN, 11));
        statusBar.setForeground(TEXT_MUTED);
        bar.add(statusBar, BorderLayout.WEST);
        JLabel info = new JLabel(db.getName() + " · " + db.getLocation());
        info.setFont(new Font("Monospaced", Font.PLAIN, 11));
        info.setForeground(TEXT_MUTED);
        bar.add(info, BorderLayout.EAST);
        return bar;
    }

    // Table refresh
    private void refreshTable() {
        tableModel.setRowCount(0);
        String selBlock  = (String) blockFilter.getSelectedItem();
        String selStatus = (String) statusFilter.getSelectedItem();
        String selSize   = sizeFilter.getText().trim();

        for (Block block : db.getBlocks()) {
            if (!"All".equals(selBlock) &&
                block.getBlockNumber() != Integer.parseInt(selBlock)) continue;
            for (Lot lot : block.getLots()) {
                if (!"All".equals(selStatus) &&
                    !lot.getStatus().toString().equals(selStatus)) continue;
                if (!selSize.isEmpty()) {
                    try { if (lot.getSize() != Double.parseDouble(selSize)) continue; }
                    catch (NumberFormatException ignored) {}
                }
                tableModel.addRow(new Object[]{
                    lot.getLotId(), lot.getBlockNumber(), lot.getLotNumber(),
                    lot.getSize(), String.format("₱%,.2f", lot.getPrice()),
                    lot.getStatus().toString(),
                    lot.getBuyer() != null ? lot.getBuyer().getName() : "—"
                });
            }
        }
        setStatus("Showing " + tableModel.getRowCount() + " lot(s).");
    }

    // Reserve Dialog
    private void showReserveDialog() {
        JDialog dlg = styledDialog("Reserve a Lot  (Admin)", 440, 300);
        dlg.setLayout(null);

        addDlgLabel(dlg, "Block # (1–5)", 16, 16);
        JTextField fBlock = styledField(); fBlock.setBounds(16, 34, 150, 30); dlg.add(fBlock);

        addDlgLabel(dlg, "Lot # (1–20)", 190, 16);
        JTextField fLot = styledField(); fLot.setBounds(190, 34, 150, 30); dlg.add(fLot);

        addDlgLabel(dlg, "Buyer Username", 16, 78);
        JTextField fBuyer = styledField(); fBuyer.setBounds(16, 96, 324, 30); dlg.add(fBuyer);

        JLabel hint = new JLabel("Enter the buyer's registered username");
        hint.setFont(new Font("Monospaced", Font.PLAIN, 9));
        hint.setForeground(TEXT_MUTED);
        hint.setBounds(16, 128, 324, 14); dlg.add(hint);

        JLabel errLabel = errLabel(dlg, 0, 148, 400);

        JButton confirm = actionButton("Process Reservation", ACCENT_BLUE);
        confirm.setBounds(16, 172, 324, 34); dlg.add(confirm);

        confirm.addActionListener(e -> {
            String blockInput = fBlock.getText().trim();
            String lotInput   = fLot.getText().trim();
            String buyerUser  = fBuyer.getText().trim();

            if (blockInput.isEmpty() || lotInput.isEmpty() || buyerUser.isEmpty()) {
                errLabel.setText("All fields are required."); return;
            }
            int blockNum, lotNum;
            try { blockNum = Integer.parseInt(blockInput); }
            catch (NumberFormatException ex) { errLabel.setText("Block # must be a number."); return; }
            try { lotNum = Integer.parseInt(lotInput); }
            catch (NumberFormatException ex) { errLabel.setText("Lot # must be a number."); return; }
            if (blockNum < 1 || blockNum > db.getTotalBlocks()) {
                errLabel.setText("Block # must be between 1 and " + db.getTotalBlocks() + "."); return; }
            if (lotNum < 1 || lotNum > db.getMaxLotsPerBlock()) {
                errLabel.setText("Lot # must be between 1 and " + db.getMaxLotsPerBlock() + "."); return; }

            Block block = db.getBlock(blockNum);
            if (block == null) { errLabel.setText("Block " + blockNum + " does not exist."); return; }
            Lot lot = block.getLot(lotNum);
            if (lot == null) { errLabel.setText("Lot " + lotNum + " does not exist in Block " + blockNum + "."); return; }
            if (!lot.isAvailable()) { errLabel.setText("Lot " + lot.getLotId() + " is already " + lot.getStatus() + "."); return; }

            // Find buyer by username
            Buyer buyer = db.getBuyers().stream()
                .filter(b -> b.getUsername().equals(buyerUser))
                .findFirst().orElse(null);
            if (buyer == null) { errLabel.setText("Buyer '" + buyerUser + "' not found."); return; }

            try {
                Transaction t = new Transaction(db.generateNextTransId(), "RESERVATION", lot, buyer);
                t.process();
                db.addTransaction(t);
                refreshTable(); revalidate(); repaint();
                setStatus("Reserved: " + lot.getLotId() + " for " + buyer.getName());
                dlg.dispose();
            } catch (Exception ex) { errLabel.setText(ex.getMessage()); }
        });

        dlg.setVisible(true);
    }

    // Buy Dialog
    private void showBuyDialog() {
        JDialog dlg = styledDialog("Process Sale  (Admin)", 440, 300);
        dlg.setLayout(null);

        addDlgLabel(dlg, "Block # (1–5)", 16, 16);
        JTextField fBlock = styledField(); fBlock.setBounds(16, 34, 150, 30); dlg.add(fBlock);

        addDlgLabel(dlg, "Lot # (1–20)", 190, 16);
        JTextField fLot = styledField(); fLot.setBounds(190, 34, 150, 30); dlg.add(fLot);

        addDlgLabel(dlg, "Buyer Username", 16, 78);
        JTextField fBuyer = styledField(); fBuyer.setBounds(16, 96, 324, 30); dlg.add(fBuyer);

        JLabel hint = new JLabel("Enter the buyer's registered username");
        hint.setFont(new Font("Monospaced", Font.PLAIN, 9));
        hint.setForeground(TEXT_MUTED);
        hint.setBounds(16, 128, 324, 14); dlg.add(hint);

        JLabel errLabel = errLabel(dlg, 0, 148, 400);

        JButton confirm = actionButton("Process Sale", ACCENT_GREEN);
        confirm.setBounds(16, 172, 324, 34); dlg.add(confirm);

        confirm.addActionListener(e -> {
            String blockInput = fBlock.getText().trim();
            String lotInput   = fLot.getText().trim();
            String buyerUser  = fBuyer.getText().trim();

            if (blockInput.isEmpty() || lotInput.isEmpty() || buyerUser.isEmpty()) {
                errLabel.setText("All fields are required."); return; }
            int blockNum, lotNum;
            try { blockNum = Integer.parseInt(blockInput); }
            catch (NumberFormatException ex) { errLabel.setText("Block # must be a number."); return; }
            try { lotNum = Integer.parseInt(lotInput); }
            catch (NumberFormatException ex) { errLabel.setText("Lot # must be a number."); return; }
            if (blockNum < 1 || blockNum > db.getTotalBlocks()) {
                errLabel.setText("Block # must be between 1 and " + db.getTotalBlocks() + "."); return; }
            if (lotNum < 1 || lotNum > db.getMaxLotsPerBlock()) {
                errLabel.setText("Lot # must be between 1 and " + db.getMaxLotsPerBlock() + "."); return; }

            Block block = db.getBlock(blockNum);
            if (block == null) { errLabel.setText("Block " + blockNum + " does not exist."); return; }
            Lot lot = block.getLot(lotNum);
            if (lot == null) { errLabel.setText("Lot " + lotNum + " does not exist in Block " + blockNum + "."); return; }
            if (lot.getStatus() == LotStatus.SOLD) {
                errLabel.setText("Lot " + lot.getLotId() + " is already SOLD."); return; }

            Buyer buyer = db.getBuyers().stream()
                .filter(b -> b.getUsername().equals(buyerUser))
                .findFirst().orElse(null);
            if (buyer == null) { errLabel.setText("Buyer '" + buyerUser + "' not found."); return; }

            if (lot.getStatus() == LotStatus.RESERVED &&
                !lot.getBuyer().getUsername().equals(buyerUser)) {
                errLabel.setText("Lot is reserved by another buyer."); return; }

            try {
                Transaction t = new Transaction(db.generateNextTransId(), "SALE", lot, buyer);
                t.process();
                db.addTransaction(t);
                refreshTable(); revalidate(); repaint();
                setStatus("Sold: " + lot.getLotId() + " to " + buyer.getName());
                dlg.dispose();
            } catch (Exception ex) { errLabel.setText(ex.getMessage()); }
        });

        dlg.setVisible(true);
    }

    // Buyer List Dialog
    private void showBuyerListDialog() {
        JDialog dlg = styledDialog("Registered Buyers", 850, 400);
        dlg.setLayout(new BorderLayout(0, 10));

        String[] cols = {"Buyer ID", "Name", "Contact", "Email", "Username"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        for (Buyer b : db.getBuyers()) {
            model.addRow(new Object[]{
                b.getBuyerId(), b.getName(), b.getContact(), b.getEmail(), b.getUsername()
            });
        }
        JTable table = new JTable(model);
        styleTable(table);
        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));
        dlg.add(sp, BorderLayout.CENTER);
        dlg.setVisible(true);
    }

    // Report
    private void showReport() {
        JDialog dlg = styledDialog("Full Subdivision Report", 980, 700);
        dlg.setLayout(new BorderLayout());
        JTextArea area = new JTextArea(db.generateReport());
        area.setFont(new Font("Monospaced", Font.PLAIN, 12));
        area.setBackground(BG_CARD);
        area.setForeground(TEXT_PRIMARY);
        area.setEditable(false);
        area.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        JScrollPane sp = new JScrollPane(area);
        sp.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));
        dlg.add(sp, BorderLayout.CENTER);
        dlg.setVisible(true);
    }

    //  HELPERS
    private void styleTable(JTable table) {
        table.setFont(new Font("Monospaced", Font.PLAIN, 12));
        table.setRowHeight(28);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 1));
        table.setBackground(BG_CARD);
        table.setForeground(TEXT_PRIMARY);
        table.setFillsViewportHeight(true);
        JTableHeader th = table.getTableHeader();
        th.setFont(new Font("Monospaced", Font.BOLD, 11));
        th.setBackground(BG_PANEL);
        th.setForeground(TEXT_MUTED);
        th.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_COLOR));
    }

    private JDialog styledDialog(String title, int w, int h) {
        JDialog dlg = new JDialog(this, title, true);
        dlg.setSize(w, h);
        dlg.setLocationRelativeTo(this);
        dlg.getContentPane().setBackground(BG_PANEL);
        ((JPanel) dlg.getContentPane()).setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
        return dlg;
    }

    private JLabel sideLabel(String text) {
        JLabel lbl = new JLabel("  " + text);
        lbl.setFont(new Font("Monospaced", Font.BOLD, 10));
        lbl.setForeground(TEXT_MUTED);
        lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        lbl.setMaximumSize(new Dimension(200, 20));
        return lbl;
    }

    private JLabel sideFilterLabel(String text) {
        JLabel lbl = new JLabel("  " + text);
        lbl.setFont(new Font("Monospaced", Font.PLAIN, 10));
        lbl.setForeground(TEXT_MUTED);
        lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        lbl.setMaximumSize(new Dimension(200, 18));
        return lbl;
    }

    private JButton sideButton(String text, Color color, ActionListener action) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Monospaced", Font.PLAIN, 12));
        btn.setForeground(color);
        btn.setBackground(BG_CARD);
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 3, 0, 0, color),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        btn.setAlignmentX(Component.LEFT_ALIGNMENT);
        btn.setMaximumSize(new Dimension(200, 40));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setFocusPainted(false);
        btn.addActionListener(action);
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btn.setBackground(BORDER_COLOR); }
            public void mouseExited(MouseEvent e)  { btn.setBackground(BG_CARD); }
        });
        return btn;
    }

    private void styleCombo(JComboBox<String> combo) {
        combo.setFont(new Font("Monospaced", Font.PLAIN, 11));
        combo.setBackground(BG_CARD);
        combo.setForeground(TEXT_PRIMARY);
        combo.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));
        combo.setMaximumSize(new Dimension(180, 30));
        combo.setAlignmentX(Component.LEFT_ALIGNMENT);
    }

    private void styleTextField(JTextField tf) {
        tf.setFont(new Font("Monospaced", Font.PLAIN, 11));
        tf.setBackground(BG_CARD);
        tf.setForeground(TEXT_PRIMARY);
        tf.setCaretColor(TEXT_PRIMARY);
        tf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR),
            BorderFactory.createEmptyBorder(4, 8, 4, 8)
        ));
        tf.setMaximumSize(new Dimension(180, 30));
        tf.setAlignmentX(Component.LEFT_ALIGNMENT);
    }

    private JTextField styledField() {
        JTextField tf = new JTextField();
        tf.setFont(new Font("Monospaced", Font.PLAIN, 12));
        tf.setBackground(BG_CARD);
        tf.setForeground(TEXT_PRIMARY);
        tf.setCaretColor(TEXT_PRIMARY);
        tf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR),
            BorderFactory.createEmptyBorder(4, 8, 4, 8)
        ));
        return tf;
    }

    private JButton actionButton(String text, Color color) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Monospaced", Font.BOLD, 12));
        btn.setForeground(Color.WHITE);
        btn.setBackground(color);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private void addDlgLabel(JDialog dlg, String text, int x, int y) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("Monospaced", Font.PLAIN, 10));
        lbl.setForeground(TEXT_MUTED);
        lbl.setBounds(x, y, 200, 16);
        dlg.add(lbl);
    }

    private JLabel errLabel(JDialog dlg, int x, int y, int w) {
        JLabel lbl = new JLabel("", SwingConstants.CENTER);
        lbl.setFont(new Font("Monospaced", Font.PLAIN, 10));
        lbl.setForeground(ACCENT_RED);
        lbl.setBounds(x, y, w, 18);
        dlg.add(lbl);
        return lbl;
    }

    private void setStatus(String msg) { statusBar.setText(msg); }
}
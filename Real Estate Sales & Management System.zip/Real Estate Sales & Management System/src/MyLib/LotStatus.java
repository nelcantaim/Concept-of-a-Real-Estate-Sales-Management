/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MyLib;

/**
 *
 * @author Quicho, Policarpio, Tolentino
 */

public enum LotStatus {

    AVAILABLE,
    RESERVED,
    SOLD
}

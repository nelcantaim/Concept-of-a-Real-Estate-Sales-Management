 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MyLib;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Rante, Tayshaun
 */

public class Subdivision {
    private static Subdivision instance;

    public static Subdivision getInstance() {
        if (instance == null) instance = new Subdivision();
        return instance;
    }

    //  Fields
    private final String name = "Sundowners";
    private final String location = "Botolan, Zambales";
    private final int totalBlocks       = 5;
    private final int maxLotsPerBlock   = 20;

    private final List<Block> blocks  = new ArrayList<>();
    private final List<Buyer> buyers  = new ArrayList<>();
    private final List<Admin>admins = new ArrayList<>();
    private final List<Transaction> transactions = new ArrayList<>();
    private int transCounter = 1;

    // Constructor
    private Subdivision() {
        initBlocks();
        initBuyers();
        initAdmins();
    }

    //  Data
    private void initBlocks() {
        String[] descriptions = {
            "North Wing", "South Wing", "East Wing", "West Wing", "Central"
        };
        double[] sizes  = { 60, 80, 100, 120, 150 };
        double[] prices = { 1_200_000, 1_600_000, 2_000_000, 2_400_000, 3_000_000 };

        for (int b = 1; b <= totalBlocks; b++) {
            Block block = new Block(b, maxLotsPerBlock, descriptions[b - 1]);
            for (int l = 1; l <= maxLotsPerBlock; l++) {
                String lotId = String.format("B%02d-L%02d", b, l);
                double size  = sizes[(l - 1) % sizes.length];
                double price = prices[(l - 1) % prices.length];
                block.addLot(new Lot(lotId, b, l, size, price));
            }
            blocks.add(block);
        }
    }

    private void initBuyers() {
        buyers.add(new Buyer("B001", "Nel Leeyan Rante", "09171234567", "nel@email.com", "nels", "pass1234"));
        buyers.add(new Buyer("B002", "Tayshaun Escudero", "09281234567", "tay@email.com",  "taysons", "pass5678"));
        buyers.add(new Buyer("B003", "Anne Nicole Quicho", "09391234567", "ana@email.com", "an", "pass9999"));
        buyers.add(new Buyer("B004", "Dominique Policarpio", "09356332314", "ni@email.com", "nik", "pass0999"));
        buyers.add(new Buyer("B005", "Maria Miel Tolentino", "09432134313", "mi@email.com",  "mari", "pass9932"));
    }
    
        private void initAdmins() {
        admins.add(new Admin("A001", "Head Admin",  "admin",  "admin123"));
        admins.add(new Admin("A002", "Sales Agent", "agent",  "agent123"));
    }

    //  Getters
    public List<Block> getBlocks() { 
        return blocks; 
    }
    
    public List<Buyer> getBuyers() { 
        return buyers; 
    }
    
    public List<Admin> getAdmins() { 
        return admins;
    }
    
    public List<Transaction> getTransactions() { 
        return transactions; 
    }
    
    public String getName() { 
        return name; 
    }
    
    public String getLocation() { 
        return location; 
    }
    
    public int getTotalBlocks() { 
        return totalBlocks; 
    }
    
    public int getMaxLotsPerBlock() { 
        return maxLotsPerBlock; 
    }

    // Get a specific block by number
    public Block getBlock(int num) {
        for (Block b : blocks)
            if (b.getBlockNumber() == num) return b;
        return null;
    }

    // Authenticate a buyer
    public Buyer authenticateBuyer(String username, String password) {
        for (Buyer b : buyers)
            if (b.login(username, password)) return b;
        return null;
    }

    // Authenticate an admin
    public Admin authenticateAdmin(String username, String password) {
        for (Admin a : admins)
            if (a.login(username, password)) return a;
        return null;
    }

    // Add a completed transaction
    public void addTransaction(Transaction t) {
        transactions.add(t);
    }

    // transaction ID
    public String generateNextTransId() {
        return String.format("TXN-%03d", transCounter++);
    }
    
    // get lots that are owned or reserved
    public List<Lot> getLotsByBuyer(Buyer buyer) {
        List<Lot> result = new ArrayList<>();
        for (Block b : blocks)
            for (Lot l : b.getLots())
                if (l.getBuyer() != null &&
                    l.getBuyer().getUsername().equals(buyer.getUsername()))
                    result.add(l);
        return result;
    }

    // Filter lots by size
    public List<Lot> getLotsBySpec(double size) {
        List<Lot> result = new ArrayList<>();
        for (Block b : blocks)
            for (Lot l : b.getLots())
                if (l.getSize() == size) result.add(l);
        return result;
    }

    // Count lots by status
    public int countByStatus(LotStatus status) {
        int count = 0;
        for (Block b : blocks)
            for (Lot l : b.getLots())
                if (l.getStatus() == status) count++;
        return count;
    }

    // Full report of all lots and their transactions
    public String generateReport() {
        StringBuilder sb = new StringBuilder();
        sb.append("==== SUBDIVISION REPORT  ====\n");
        sb.append("Name     : ").append(name).append("\n");
        sb.append("Location : ").append(location).append("\n\n");

        for (Block b : blocks) {
            sb.append("-- Block ").append(b.getBlockNumber())
              .append(" (").append(b.getDescription()).append(") --\n");
            for (Lot l : b.getLots())
                sb.append("  ").append(l.getInfo()).append("\n");
            sb.append("\n");
        }

        if (!transactions.isEmpty()) {
            sb.append("=== TRANSACTION LOG ===\n");
            for (Transaction t : transactions)
                sb.append("  ").append(t.getSummary()).append("\n");
        }

        return sb.toString();
    }
}
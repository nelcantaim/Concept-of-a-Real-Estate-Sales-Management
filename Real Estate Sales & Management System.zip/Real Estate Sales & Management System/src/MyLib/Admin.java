/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MyLib;

/**
 *
 * @author leeyan
 */

public class Admin {

    private String adminId;
    private String name;
    private String username;
    private String password;

    public Admin(String adminId, String name, String username, String password) {
        this.adminId  = adminId;
        this.name     = name;
        this.username = username;
        this.password = password;
    }

    // Returns true if credentials match
    public boolean login(String inputUsername, String inputPassword) {
        return this.username.equals(inputUsername) &&
               this.password.equals(inputPassword);
    }

    public void logout() {
        System.out.println(name + " (Admin) has logged out.");
    }

    // Getters
    public String getAdminId()  { return adminId; }
    public String getName()     { return name; }
    public String getUsername() { return username; }

    public String getInfo() {
        return "Admin ID: " + adminId + " | Name: " + name;
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MyLib;

/**
 *
 * @author Quicho, Policarpio, Tolentino
 */

public class Buyer {
    
    private String buyerId;
    private String name;
    private String contact;
    private String email;
    private String username;
    private String password;

    public Buyer(String buyerId, String name, String contact, String email, String username, String password){
        this.buyerId = buyerId;
        this.name = name;
        this.contact = contact;
        this.email = email;
        this.username = username;
        this.password = password;
    }
    
    public boolean login(String inputUsername, String inputPassword) {
        return this.username.equals(inputUsername) &&
               this.password.equals(inputPassword);
    }

    public void logout(){
        System.out.println(name + " has logged out");
    }
    
    public String getBuyerId() { 
        return buyerId; 
    }
    
    public String getName() { 
        return name; 
    }
    
    public String getContact() { 
        return contact; 
    }
    
    public String getUsername () {
        return username;
    }
    
    public String getEmail() { return email; }

    public String getInfo() {
        return "ID: " + buyerId + " | Name: " + name +
               " | Contact: " + contact + " | Email: " + email;
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MyLib;
import java.time.LocalDate;
/**
 *
 * @author Quicho, Policarpio, Tolentino
 */

import java.time.LocalDate;

public class Transaction {
    private String transId;
    private LocalDate date;
    private String type;   // "RESERVATION" or "SALE"
    private Lot lot;
    private Buyer buyer;

    public Transaction(String transId, String type, Lot lot, Buyer buyer) {
        this.transId = transId;
        this.date = LocalDate.now();
        this.type = type;
        this.lot = lot;
        this.buyer = buyer;
    }

    public void process() {
        if (type.equals("RESERVATION")) {
            lot.reserve(buyer);
        } else if (type.equals("SALE")) {
            lot.sell(buyer);
        } else {
            throw new IllegalArgumentException("Unknown transaction type: " + type);
        }
    }

    public String getSummary() {
        return String.format("Trans ID: %s | Date: %s | Type: %s | Lot: %s | Buyer: %s",
                transId, date, type, lot.getLotId(), buyer.getName());
    }

    // Getters
    public String getTransId()  { return transId; }
    public LocalDate getDate()  { return date; }
    public String getType()     { return type; }
    public Lot getLot()         { return lot; }
    public Buyer getBuyer()     { return buyer; }
    
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MyLib;

/**
 *
 * @author Quicho, Policarpio, Tolentino
 */
 
public class Lot {
    private String lotId;
    private int blockNumber;
    private int lotNumber;
    private double size;   // sqr meters
    private double price;
    private LotStatus status;
    private Buyer buyer;

    public Lot(String lotId, int blockNumber, int lotNumber, double size, double price) {
        this.lotId = lotId;
        this.blockNumber = blockNumber;
        this.lotNumber = lotNumber;
        this.size = size;
        this.price = price;
        this.status = LotStatus.AVAILABLE;
        this.buyer = null;
    }

    // Reserve a lot for a buyer
    public void reserve(Buyer b) {
        if (status == LotStatus.AVAILABLE) {
            this.buyer = b;
            this.status = LotStatus.RESERVED;
        } else {
            throw new IllegalStateException("Lot " + lotId + " is not available for reservation.");
        }
    }

    // Sell a lot to a buyer
    public void sell(Buyer b) {
        if (status == LotStatus.AVAILABLE || status == LotStatus.RESERVED) {
            this.buyer = b;
            this.status = LotStatus.SOLD;
        } else {
            throw new IllegalStateException("Lot " + lotId + " is already sold.");
        }
    }

    public boolean isAvailable() {
        return status == LotStatus.AVAILABLE;
    }

    public String getInfo() {
        return String.format("Lot ID: %s | Block: %d | Lot#: %d | Size: %.1f sqm | Price: PHP %.2f | Status: %s | Buyer: %s",
                lotId, blockNumber, lotNumber, size, price, status,
                buyer != null ? buyer.getName() : "N/A");
    }
    
// Getters & Setters
    public String getLotId()       { return lotId; }
    public int getBlockNumber()    { return blockNumber; }
    public int getLotNumber()      { return lotNumber; }
    public double getSize()        { return size; }
    public double getPrice()       { return price; }
    public LotStatus getStatus()   { return status; }
    public Buyer getBuyer()        { return buyer; }

    public void setStatus(LotStatus status) { this.status = status; }
    public void setBuyer(Buyer buyer)       { this.buyer = buyer; }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Quicho, Policarpio, Tolentino
 */

package MyLib;
import java.util.ArrayList;
import java.util.List;

public class Block {

    private int blockNumber;
    private int totalLots;
    private String description;
    private List<Lot> lots;

    // Constructor
    public Block(int blockNumber, int totalLots, String description) {
        this.blockNumber = blockNumber;
        this.totalLots = totalLots;
        this.description = description;
        this.lots = new ArrayList<>();
    }

    // Add lot to block
    public void addLot(Lot lot) {
        if (lots.size() < totalLots) {
            lots.add(lot);
        } else {
            System.out.println("Maximum lots reached for this block.");
        }
    }

    // Get lot by lot number
    public Lot getLot(int num) {
        for (Lot lot : lots) {
            if (lot.getLotNumber() == num) {
                return lot;
            }
        }
        return null;
    }

    // Get all available lots
    public List<Lot> getAvailableLots() {
        List<Lot> availableLots = new ArrayList<>();

        for (Lot lot : lots) {
            if (lot.isAvailable()) {
                availableLots.add(lot);
            }
        }

        return availableLots;
    }

    // Getters
    public int getBlockNumber() {
        return blockNumber;
    }

    public int getTotalLots() {
        return totalLots;
    }

    public String getDescription() {
        return description;
    }

    public List<Lot> getLots() {
        return lots;
    }

    // Display block info
    public void displayBlockInfo() {
        System.out.println("Block Number: " + blockNumber);
        System.out.println("Total Lots: " + totalLots);
        System.out.println("Description: " + description);
    }
}